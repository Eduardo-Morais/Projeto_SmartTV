#include "pessoa.h"


Pessoa::Pessoa(string n){
  setnome(n);
}

void Pessoa::setnome(string n){
  nome=n;
}